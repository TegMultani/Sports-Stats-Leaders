import requests
import json
import pandas as pd
import numpy as np

ended = 0

pd.set_option("display.colheader_justify","center")

while ended == 0:
    league = input("NHL or MLB?: ")

    if league.lower() == 'nhl':
        endedNHL = 0
        while endedNHL == 0:
            print()
            print()
            statNHL = input("Goals, Assists, or Points?: ")
            if statNHL.lower() == 'points':

                        url = "https://api.nhle.com/stats/rest/en/leaders/skaters/points?cayenneExp=season=20202021%20and%20gameType=2"

                        payload={}
                        headers = {
                          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                          'Accept': '*/*',
                          'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                          'Referer': 'http://www.nhl.com/',
                          'Origin': 'http://www.nhl.com',
                          'Connection': 'keep-alive',
                          'TE': 'Trailers'
                        }

                        r = requests.get(url, headers=headers)

                        playerdata = r.json()

                        dataframe = pd.json_normalize(playerdata['data'])
                        dataframe.columns = ['PTS', 'ID', 'TeamID', 'First Name', 'Name', 'Last Name', 'Position', '#', 'Team ID', 'Franchise ID', 'Team Name', 'League ID', 'Logo', 'Code', 'Team']

                        new_df = dataframe.replace(['R', 'L'], ['RW', 'LW'])
                        new_df.index = np.arange(1,len(new_df)+1)

                        players = new_df.head(10)

                        print()
                        print(players[['Name', 'PTS', 'Position', 'Team']])
                        print()
                        print()
                        endedNHL = 1
            elif statNHL.lower() == 'goals':

                url = "https://api.nhle.com/stats/rest/en/leaders/skaters/goals?cayenneExp=season=20202021%20and%20gameType=2"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'http://www.nhl.com/',
                  'Origin': 'http://www.nhl.com',
                  'Connection': 'keep-alive',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()

                dataframe = pd.json_normalize(playerdata['data'])
                dataframe.columns = ['Goals', 'ID', 'TeamID', 'First Name', 'Name', 'Last Name', 'Position', '#', 'Team ID', 'Franchise ID', 'Team Name', 'League ID', 'Logo', 'Code', 'Team']

                new_df = dataframe.replace(['R', 'L'], ['RW', 'LW'])
                new_df.index = np.arange(1,len(new_df)+1)
                players = new_df.head(10)

                print()
                print(players[['Name', 'Goals', 'Position', 'Team']])
                print()
                print()
                endedNHL = 1
            elif statNHL.lower() == "assists":

                url = "https://api.nhle.com/stats/rest/en/leaders/skaters/assists?cayenneExp=season=20202021%20and%20gameType=2"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'http://www.nhl.com/',
                  'Origin': 'http://www.nhl.com',
                  'Connection': 'keep-alive',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()

                dataframe = pd.json_normalize(playerdata['data'])
                dataframe.columns = ['Assists', 'ID', 'TeamID', 'First Name', 'Name', 'Last Name', 'Position', '#', 'Team ID', 'Franchise ID', 'Team Name', 'League ID', 'Logo', 'Code', 'Team']

                new_df = dataframe.replace(['R', 'L'], ['RW', 'LW'])
                new_df.index = np.arange(1,len(new_df)+1)
                players = new_df.head(10)

                print()
                print(players[['Name', 'Assists', 'Position', 'Team']])
                print()
                print()
                endedNHL = 1
            else:
                print()
                print()
                print('Please Select A Correct Response')

    elif league.lower() == 'mlb':
        endedMLB = 0
        while endedMLB == 0:
            print()
            print()
            statMLB = input("HR, RBI, Avg, SB, ERA: ")
            if statMLB.lower() == 'hr':
                url = "https://bdfed.stitch.mlbinfra.com/bdfed/stats/player?stitch_env=prod&season=2021&sportId=1&stats=season&group=hitting&gameType=R&offset=0&sortStat=homeRuns&order=desc"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'https://www.mlb.com/',
                  'Origin': 'https://www.mlb.com',
                  'Connection': 'keep-alive',
                  'Cache-Control': 'max-age=0',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()
                dataframe = pd.json_normalize(playerdata['stats'])
                dataframe.columns = ['year', 'playerId', 'Name', 'type', 'rank', 'playerFullName', 'playerFirstName', 'playerLastName', 'playerUseName', 'playerInitLastName', 'teamId', 'Team', 'teamName', 'teamShortName', 'leagueName', 'leagueId', 'Position', 'position', 'primaryPositionAbbrev', 'plateAppearances', 'totalBases', 'leftOnBase', 'sacBunts', 'sacFlies', 'babip', 'extraBaseHits', 'hitByPitch', 'gidp', 'gidpOpp', 'numberOfPitches', 'pitchesPerPlateAppearance', 'walksPerPlateAppearance', 'strikeoutsPerPlateAppearance', 'homeRunsPerPlateAppearance', 'walksPerStrikeout', 'iso', 'reachedOnError', 'walkOffs', 'flyOuts', 'totalSwings', 'swingAndMisses', 'ballsInPlay', 'popOuts', 'lineOuts', 'groundOuts', 'flyHits', 'popHits', 'lineHits', 'groundHits', 'gamesPlayed', 'airOuts', 'runs', 'doubles', 'triples', 'Home Runs', 'strikeOuts', 'baseOnBalls', 'intentionalWalks', 'hits', 'AVG', 'atBats', 'obp', 'slg', 'ops', 'caughtStealing', 'SB', 'stolenBasePercentage', 'groundIntoDoublePlay', 'RBI', 'groundOutsToAirouts', 'catchersInterference', 'AB/HR']

                dataframe.index = np.arange(1,len(dataframe)+1)

                players = dataframe.head(10)

                print()
                print(players[['Name', 'Home Runs', 'AB/HR', 'RBI', 'AVG', 'Position', 'Team',]])
                print()
                print()
                endedMLB = 1
            elif statMLB.lower() == 'rbi':

                url = "https://bdfed.stitch.mlbinfra.com/bdfed/stats/player?stitch_env=prod&season=2021&sportId=1&stats=season&group=hitting&gameType=R&limit=25&offset=0&sortStat=runsBattedIn&order=desc"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'https://www.mlb.com/',
                  'Origin': 'https://www.mlb.com',
                  'Connection': 'keep-alive',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()

                dataframe = pd.json_normalize(playerdata['stats'])
                dataframe.columns = ['year', 'playerId', 'Name', 'type', 'rank', 'playerFullName', 'playerFirstName', 'playerLastName', 'playerUseName', 'playerInitLastName', 'teamId', 'Team', 'teamName', 'teamShortName', 'leagueName', 'leagueId', 'Position', 'position', 'primaryPositionAbbrev', 'plateAppearances', 'totalBases', 'leftOnBase', 'sacBunts', 'sacFlies', 'babip', 'extraBaseHits', 'hitByPitch', 'gidp', 'gidpOpp', 'numberOfPitches', 'pitchesPerPlateAppearance', 'walksPerPlateAppearance', 'strikeoutsPerPlateAppearance', 'homeRunsPerPlateAppearance', 'walksPerStrikeout', 'iso', 'reachedOnError', 'walkOffs', 'flyOuts', 'totalSwings', 'swingAndMisses', 'ballsInPlay', 'popOuts', 'lineOuts', 'groundOuts', 'flyHits', 'popHits', 'lineHits', 'groundHits', 'gamesPlayed', 'airOuts', 'runs', 'doubles', 'triples', 'Home Runs', 'strikeOuts', 'baseOnBalls', 'intentionalWalks', 'hits', 'AVG', 'atBats', 'obp', 'slg', 'ops', 'caughtStealing', 'SB', 'stolenBasePercentage', 'groundIntoDoublePlay', 'RBI', 'groundOutsToAirouts', 'catchersInterference', 'AB/HR']

                dataframe.index = np.arange(1,len(dataframe)+1)

                players = dataframe.head(10)

                print()
                print(players[['Name', 'RBI', 'AVG', 'Home Runs', 'Position', 'Team']])
                print()
                print()
                endedMLB = 1
            elif statMLB.lower() == 'avg':

                url = "https://bdfed.stitch.mlbinfra.com/bdfed/stats/player?stitch_env=prod&season=2021&sportId=1&stats=season&group=hitting&gameType=R&offset=0&sortStat=battingAverage&order=desc"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'https://www.mlb.com/',
                  'Origin': 'https://www.mlb.com',
                  'Connection': 'keep-alive',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()

                dataframe = pd.json_normalize(playerdata['stats'])
                dataframe.columns = ['year', 'playerId', 'Name', 'type', 'rank', 'playerFullName', 'playerFirstName', 'playerLastName', 'playerUseName', 'playerInitLastName', 'teamId', 'Team', 'teamName', 'teamShortName', 'leagueName', 'leagueId', 'Position', 'position', 'primaryPositionAbbrev', 'plateAppearances', 'totalBases', 'leftOnBase', 'sacBunts', 'sacFlies', 'babip', 'extraBaseHits', 'hitByPitch', 'gidp', 'gidpOpp', 'numberOfPitches', 'pitchesPerPlateAppearance', 'walksPerPlateAppearance', 'strikeoutsPerPlateAppearance', 'homeRunsPerPlateAppearance', 'walksPerStrikeout', 'iso', 'reachedOnError', 'walkOffs', 'flyOuts', 'totalSwings', 'swingAndMisses', 'ballsInPlay', 'popOuts', 'lineOuts', 'groundOuts', 'flyHits', 'popHits', 'lineHits', 'groundHits', 'gamesPlayed', 'airOuts', 'runs', 'doubles', 'triples', 'Home Runs', 'strikeOuts', 'baseOnBalls', 'intentionalWalks', 'hits', 'AVG', 'atBats', 'obp', 'slg', 'ops', 'caughtStealing', 'SB', 'stolenBasePercentage', 'groundIntoDoublePlay', 'RBI', 'groundOutsToAirouts', 'catchersInterference', 'AB/HR']

                dataframe.index = np.arange(1,len(dataframe)+1)

                players = dataframe.head(10)

                print()
                print(players[['Name', 'AVG', 'RBI', 'Home Runs', 'Position', 'Team']])
                print()
                print()
                endedMLB = 1
            elif statMLB.lower() == "sb":

                url = "https://bdfed.stitch.mlbinfra.com/bdfed/stats/player?stitch_env=prod&season=2021&sportId=1&stats=season&group=hitting&gameType=R&offset=0&sortStat=stolenBases&order=desc"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'https://www.mlb.com/',
                  'Origin': 'https://www.mlb.com',
                  'Connection': 'keep-alive',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()

                dataframe = pd.json_normalize(playerdata['stats'])
                dataframe.columns = ['year', 'playerId', 'Name', 'type', 'rank', 'playerFullName', 'playerFirstName', 'playerLastName', 'playerUseName', 'playerInitLastName', 'teamId', 'Team', 'teamName', 'teamShortName', 'leagueName', 'leagueId', 'Position', 'position', 'primaryPositionAbbrev', 'plateAppearances', 'totalBases', 'leftOnBase', 'sacBunts', 'sacFlies', 'babip', 'extraBaseHits', 'hitByPitch', 'gidp', 'gidpOpp', 'numberOfPitches', 'pitchesPerPlateAppearance', 'walksPerPlateAppearance', 'strikeoutsPerPlateAppearance', 'homeRunsPerPlateAppearance', 'walksPerStrikeout', 'iso', 'reachedOnError', 'walkOffs', 'flyOuts', 'totalSwings', 'swingAndMisses', 'ballsInPlay', 'popOuts', 'lineOuts', 'groundOuts', 'flyHits', 'popHits', 'lineHits', 'groundHits', 'gamesPlayed', 'airOuts', 'runs', 'doubles', 'triples', 'Home Runs', 'strikeOuts', 'baseOnBalls', 'intentionalWalks', 'hits', 'AVG', 'atBats', 'obp', 'slg', 'ops', 'caughtStealing', 'SB', 'SB%', 'groundIntoDoublePlay', 'RBI', 'groundOutsToAirouts', 'catchersInterference', 'AB/HR']

                dataframe.index = np.arange(1,len(dataframe)+1)

                players = dataframe.head(10)

                print()
                print(players[['Name', 'SB', 'SB%', 'AVG', 'RBI', 'Home Runs', 'Position', 'Team']])
                print()
                print()
                endedMLB = 1
            elif statMLB.lower() == 'era':

                url = "https://bdfed.stitch.mlbinfra.com/bdfed/stats/player?stitch_env=prod&season=2021&sportId=1&stats=season&group=pitching&gameType=R&offset=0&sortStat=earnedRunAverage&order=asc"

                payload={}
                headers = {
                  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
                  'Accept': '*/*',
                  'Accept-Language': 'en-CA,en-US;q=0.7,en;q=0.3',
                  'Referer': 'https://www.mlb.com/',
                  'Origin': 'https://www.mlb.com',
                  'Connection': 'keep-alive',
                  'TE': 'Trailers'
                }

                r = requests.get(url, headers=headers)

                playerdata = r.json()

                dataframe = pd.json_normalize(playerdata['stats'])
                dataframe.columns = ['year', 'playerId', 'Name', 'type', 'rank', 'playerFullName', 'playerFirstName', 'playerLastName', 'playerUseName', 'playerInitLastName', 'teamId', 'Team', 'teamName', 'teamShortName', 'leagueName', 'leagueId', 'positionAbbrev', 'position', 'primaryPositionAbbrev', 'winningPercentage', 'runsScoredPer9', 'battersFaced', 'babip', 'obp', 'slg', 'ops', 'strikeoutsPer9', 'baseOnBallsPer9', 'homeRunsPer9', 'hitsPer9', 'strikesoutsToWalks', 'inheritedRunners', 'inheritedRunnersScored', 'bequeathedRunners', 'bequeathedRunnersScored', 'stolenBases', 'caughtStealing', 'qualityStarts', 'gamesFinished', 'doubles', 'triples', 'gidp', 'gidpOpp', 'wildPitches', 'balks', 'pickoffs', 'totalSwings', 'swingAndMisses', 'ballsInPlay', 'runSupport', 'strikePercentage', 'pitchesPerInning', 'pitchesPerPlateAppearance', 'walksPerPlateAppearance', 'strikeoutsPerPlateAppearance', 'homeRunsPerPlateAppearance', 'walksPerStrikeout', 'iso', 'flyOuts', 'popOuts', 'lineOuts', 'groundOuts', 'flyHits', 'popHits', 'lineHits', 'groundHits', 'gamesPlayed', 'gamesStarted', 'airOuts', 'runs', 'homeRuns', 'strikeOuts', 'baseOnBalls', 'intentionalWalks', 'hits', 'hitByPitch', 'AVG', 'atBats', 'stolenBasePercentage', 'groundIntoDoublePlay', 'numberOfPitches', 'ERA', 'inningsPitched', 'wins', 'losses', 'saves', 'saveOpportunities', 'holds', 'blownSaves', 'earnedRuns', 'whip', 'outs', 'gamesPitched', 'completeGames', 'shutouts', 'strikes', 'hitBatsmen', 'totalBases', 'groundOutsToAirouts', 'winPercentage', 'strikeoutWalkRatio', 'strikeoutsPer9Inn', 'BB/9', 'hitsPer9Inn', 'catchersInterference', 'sacBunts', 'sacFlies']

                dataframe.index = np.arange(1,len(dataframe)+1)

                players = dataframe.head(10)
                print()
                print(players[['Name', 'ERA', 'BB/9', 'AVG' ,'Team']])
                print()
                print()
                endedMLB = 1
            else:
                print()
                print('Please Select a Correct Response')
